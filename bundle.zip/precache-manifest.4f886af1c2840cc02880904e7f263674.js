self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "a29e0d102c2f473e86712d53cf77be1a",
    "url": "/index.html"
  },
  {
    "revision": "d9389bfa6a3148fbebae",
    "url": "/static/css/2.09e62520.chunk.css"
  },
  {
    "revision": "bc4f725aa832f0116c6d",
    "url": "/static/css/main.bd419fe9.chunk.css"
  },
  {
    "revision": "d9389bfa6a3148fbebae",
    "url": "/static/js/2.049b3d2a.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "/static/js/2.049b3d2a.chunk.js.LICENSE.txt"
  },
  {
    "revision": "bc4f725aa832f0116c6d",
    "url": "/static/js/main.7914a6a4.chunk.js"
  },
  {
    "revision": "e1a635096941ed215cd9",
    "url": "/static/js/runtime-main.70f74ae7.js"
  },
  {
    "revision": "7c2432c1e6084430e585755d35dde07d",
    "url": "/static/media/001-happy.7c2432c1.svg"
  },
  {
    "revision": "fdf62cf64962ade0dee72dec4eaf3336",
    "url": "/static/media/003-crying.fdf62cf6.svg"
  },
  {
    "revision": "92daac61f063b1adc9f43f79c5a7105a",
    "url": "/static/media/004-angry.92daac61.svg"
  },
  {
    "revision": "d770832590f7c35d2cef0da955eca0c5",
    "url": "/static/media/017-cool.d7708325.svg"
  },
  {
    "revision": "9fd245b144801174c0d3341ae4737846",
    "url": "/static/media/021-sleeping.9fd245b1.svg"
  },
  {
    "revision": "9a363726c525140de2ac751054761f65",
    "url": "/static/media/050-calm.9a363726.svg"
  }
]);